using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Calendar
{
    public class CalendarEntries : List<ICalendarEntry>
     {
        public bool Load(string calendarEntriesFile)
        {
            StreamReader fileOpen = null;
            Entry _entry = null;
            ReccuringEntry _reccuringEntry = null;
            bool status = true;
            string lineReadFromFile;
            int entryType;

            try
            {
                fileOpen = new StreamReader(calendarEntriesFile, false);
                lineReadFromFile = fileOpen.ReadLine();

                while (lineReadFromFile != null)
                {
                    string[] type = lineReadFromFile.Split(',');
                    entryType = type.Count();

                    if (entryType <= 4)
                    {
                        _entry = new Entry(lineReadFromFile);
                        this.Add(_entry);
                    }
                    else
                    {
                        _reccuringEntry = new ReccuringEntry(lineReadFromFile);
                        this.Add(_reccuringEntry);
                    }
                    lineReadFromFile = fileOpen.ReadLine();
                }
            }

            catch (Exception)
            {
                status = false;
            }

            finally
            {
                if (fileOpen != null)
                {
                    fileOpen.Close();
                }
            }

            return status;
        }

        public bool Save(string calendarEntriesFile)
        {
            StreamWriter fileSave = null;
            bool status = true;
            
            try
            {
                fileSave = new StreamWriter(calendarEntriesFile, false);
                for (int i = 0; i < this.Count; i++)
                {
                    fileSave.WriteLine(this[i].SavedData);
                }
            }

            catch (Exception)
            {
                status = false;
            }
            finally
            {
                if (fileSave != null)
                {
                    fileSave.Close();
                }
            }
            return status;
        }

        // Iterate through the collection, returning the calendar entries that
        // occur on the specified date

        public IEnumerable<ICalendarEntry> GetCalendarEntriesOnDate(DateTime date)
        {
            for (int i = 0; i < this.Count; i++ )
            {
                if (this[i].OccursOnDate(date))
                {
                    yield return this[i];                
                }
            }
        }
    }
}