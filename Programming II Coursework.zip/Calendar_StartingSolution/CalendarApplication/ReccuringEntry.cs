﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calendar
{
    public class ReccuringEntry : ICalendarEntry
    {
        string _Subject;
        string _Location;
        string data;
        string selectedDate;
        string splitTime;
        string frequency;
        int occurrences;
        DateTime _Start;
        DateTime testDate;
        int _Length;
        int numberOfDays;

        bool status = true;

        public ReccuringEntry(string Line)
        {
            data = Line;
            string[] splitEntry = data.Split(',');
            _Subject = splitEntry[0];
            _Location = splitEntry[1];
            _Start = Convert.ToDateTime(splitEntry[2]);
            frequency = splitEntry[4];

            if (!int.TryParse(splitEntry[3], out _Length))
            {
                _Length = 30;
            }
            if(!int.TryParse(splitEntry[5], out occurrences))
            {
                occurrences = 1;
            }

            switch (frequency)
            {
                case "Daily":
                    numberOfDays = 1;
                    break;

                case "Weekly":
                    numberOfDays = 7;
                    break;

                case "Fortnightly":
                    numberOfDays = 14;
                    break;

                default:
                    numberOfDays = 1;
                    break;
            }
        }

        public DateTime Start
        {
            get
            {
                return _Start;
            }
        }

        public int Length
        {
            get
            {
                return _Length;
            }
        }

        public string DisplayText
        {
            get
            {
                return _Subject + ", " + _Location + " (Recurring " + frequency + ")";
            }
        }

        public string SavedData
        {
            get
            {
                return _Subject + "," + _Location + "," + _Start + "," + _Length + "," + frequency + "," + occurrences;
            }
        }

        bool ICalendarEntry.OccursOnDate(DateTime date)
        {
            status = false;

            for (int i = 0; i < occurrences; i++)
            {
                testDate = _Start;
                if (occurrences != 1)
                {
                    if (frequency == "Monthly")
                    {
                        testDate = testDate.AddMonths(1 * i);
                    }
                    else if (frequency == "Yearly")
                    {
                        testDate = testDate.AddYears(1 * i);
                    }
                    else
                    {
                        testDate = testDate.AddDays(numberOfDays * i);
                    }
                }

                selectedDate = date.ToString();
                splitTime = testDate.ToString();
                string[] dateSplit = selectedDate.Split(' ');
                string[] timeSplit = splitTime.Split(' ');

                if (dateSplit[0] == timeSplit[0])
                {
                    status = true;
                    return status;
                }
            }
            return status;  
        }
    }
}
