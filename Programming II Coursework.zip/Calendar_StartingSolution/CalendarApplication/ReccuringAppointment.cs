﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calendar
{
    public partial class ReccuringAppointment : Form
    {
        ReccuringEntry _entry = null;
        string data;
        string location;
        string subject;
        string sDate;
        string frequency;
        int occurrences;
        int length;
        DateTime date;

        public ReccuringEntry ReccuringEntry
        {
            get
            {
                return _entry;
            }
        }

        public ReccuringAppointment(DateTime _date)
        {
            InitializeComponent();
            date = _date;
            labelCurrentDate.Text = _date.ToLongDateString();
            comboBoxLength.SelectedIndex = 0;
            comboBoxStart.SelectedIndex = 18;
            comboBoxFrequency.SelectedIndex = 0;
        }

        public ReccuringAppointment(string entryData)
        {
            InitializeComponent();

            string[] splitData = entryData.Split(',');
            string[] splitDate = splitData[2].Split(' ');

            date = Convert.ToDateTime(splitDate[0]);
            labelCurrentDate.Text = date.ToLongDateString();



            textBoxSubject.Text = splitData[0];
            textBoxLocation.Text = splitData[1];
            comboBoxStart.SelectedIndex = comboBoxStart.FindStringExact(splitDate[1] + " " + splitDate[2]);
            comboBoxLength.SelectedIndex = comboBoxLength.FindStringExact(splitData[3]);
            comboBoxFrequency.SelectedIndex = comboBoxFrequency.FindStringExact(splitData[4]);
            textBoxTimes.Text = splitData[5];
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;

            sDate = Convert.ToString(date);
            string[] splitDate = sDate.Split(' ');
            date = Convert.ToDateTime(splitDate[0] + " " + comboBoxStart.Text);
            subject = textBoxSubject.Text;
            location = textBoxLocation.Text;
            frequency = comboBoxFrequency.Text;
            if(!int.TryParse(textBoxTimes.Text, out occurrences) || occurrences < 1 || occurrences > 999)
            {
                occurrences = 1;
            }
            int.TryParse(comboBoxLength.Text, out length);

            data = subject + "," + location + "," + date + "," + length + "," + frequency + "," + occurrences;
            _entry = new ReccuringEntry(data);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
