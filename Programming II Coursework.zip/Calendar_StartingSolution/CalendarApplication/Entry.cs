﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calendar
{
    public class Entry : ICalendarEntry
    {
        string _Subject;
        string _Location;
        string data;
        string selectedDate;
        string splitTime;
        DateTime _Start;
        int _Length;

        bool status = true;

        public Entry(string Line)
        {
            data = Line;
            string[] splitEntry = data.Split(',');
            _Subject = splitEntry[0];
            _Location = splitEntry[1];
            _Start = Convert.ToDateTime(splitEntry[2]);
            if(!int.TryParse(splitEntry[3], out _Length))
            {
                _Length = 30;
            }
            
        }

        public DateTime Start
        {
            get
            {
                return _Start;
            }
        }

        public int Length
        {
            get
            {
                return _Length;
            }
        }

        public string DisplayText
        {
            get
            {
                return _Subject + ", " + _Location;
            }
        }

        public string SavedData
        {
            get
            {
                return _Subject + "," + _Location + "," + _Start + "," + _Length;
            }
        }

        bool ICalendarEntry.OccursOnDate(DateTime date)
        {
            status = true;
            selectedDate = date.ToString();
            splitTime = _Start.ToString();
            string[] dateSplit = selectedDate.Split(' ');
            string[] timeSplit = splitTime.Split(' ');

            if (dateSplit[0] != timeSplit[0])
            {
                status = false;
            }
            return status;
        }
    }
}
