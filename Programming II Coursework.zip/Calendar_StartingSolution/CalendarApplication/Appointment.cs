﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calendar
{
    public partial class Appointment : Form
    {
        Entry _entry = null;
        string data;
        string location;
        string subject;
        string sDate;
        string startTime;
        int length;
        DateTime date;

        public Appointment(DateTime _date)
        {
            InitializeComponent();
            date = _date;
            labelCurrentDate.Text = _date.ToLongDateString();
            comboBoxLength.SelectedIndex = 0;
            comboBoxStart.SelectedIndex = 18;
        }


        //This constructor is for entries that are being edited
        //so is passed the data and populates the form
        public Appointment(DateTime _date, string entryData)
        {
            InitializeComponent();
            date = _date;
            labelCurrentDate.Text = _date.ToLongDateString();

            string[] splitData = entryData.Split(',');
            string[] splitDate = splitData[2].Split(' ');

            textBoxSubject.Text = splitData[0];
            textBoxLocation.Text = splitData[1];
            comboBoxStart.SelectedIndex = comboBoxStart.FindStringExact(splitDate[1] + " " + splitDate[2]);
            comboBoxLength.SelectedIndex = comboBoxLength.FindStringExact(splitData[3]);
        }

        public Entry Entry
        {
            get
            {
                return _entry;
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;

            sDate = Convert.ToString(date);
            string[] splitDate = sDate.Split(' ');
            date = Convert.ToDateTime(splitDate[0] + " " + comboBoxStart.Text);
            subject = textBoxSubject.Text;
            location = textBoxLocation.Text;
            int.TryParse(comboBoxLength.Text, out length);
            data = subject + "," + location + "," + date + "," + length;
            _entry = new Entry(data);
        }
    }
}
